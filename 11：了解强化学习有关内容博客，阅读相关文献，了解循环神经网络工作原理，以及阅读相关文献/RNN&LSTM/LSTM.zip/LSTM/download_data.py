import math
import os
import random
import zipfile
import numpy as np
import urllib
import tensorflow as tf

url = 'http://mattmahoney.net/dc/'

def maybe_download(file_name,expected_bytes):
	if not os.path.exists(file_name):
		file_name, _ = urllib.request.urlretrieve(url + file_name,file_name)
	statinfo = os.stat(file_name)
	if statinfo.st_size == expected_bytes:
		print('found and varified',file_name)
	else:
		print(statinfo.st_size)
		raise Exception(
			'failed to varified' + file_name +'.Can you get it on a brawser?'
			)
	return file_name

def read_data(file_name):
	with zipfile.ZipFile(file_name) as f:
		data = tf.compat.as_str(f.read(f.namelist()[0])).split()
	return data