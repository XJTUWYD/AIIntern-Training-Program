import download_data as dt
import collections
import random
import numpy as np
import tensorflow as tf
import math

file_name = dt.maybe_download('text8.zip',31344016)
words = dt.read_data(file_name)
print('Data Size:',len(words))

vocabulary_size = 50000

def build_dataset(words):
	count = [['UNK',-1]]
	count.extend(collections.Counter(words).most_common(vocabulary_size - 1))
	dictionary = dict()
	for word, _ in count:
		dictionary[word] = len(dictionary)
	data = list()
	unk_count = 0
	for word in words:
		if word in dictionary:
			index = dictionary[word]
		else:
			index = 0
			unk_count = unk_count + 1
		data.append(index)
	count[0][1] = unk_count
	reverse_dictionary = dict(zip(dictionary.values(),dictionary.keys()))
	return data,count,dictionary,reverse_dictionary

data,count,dictionary,reverse_dictionary = build_dataset(words)

data_index = 0

del words

def gernerate_batch(batch_size,num_skips,skip_window):
	global data_index
	assert batch_size % num_skips == 0
	assert num_skips <= 2*skip_window
	batch = np.ndarray(shape = (batch_size),dtype = np.int32)
	labels = np.ndarray(shape = (batch_size,1),dtype = np.int32)
	span = 2*skip_window + 1
	buffer = collections.deque(maxlen = span)
	for _ in range(span):
		buffer.append(data[data_index])
		data_index = (data_index + 1)%len(data)
	for i in range(batch_size // num_skips):
		target = skip_window
		target_to_avoid  = [skip_window]
		for j in range(num_skips):
			while target in target_to_avoid:
				target = random.randint(0,span - 1)
			target_to_avoid.append(target)
			batch[i*num_skips + j] = buffer[skip_window]
			labels[i*num_skips + j,0] = buffer[target]
		buffer.append(data[data_index])
		data_index = (data_index + 1)%len(data)
	return batch,labels

batch_size = 128
embedding_size = 128
skip_window = 1
num_skips = 2
vaild_size = 16
valid_window = 100
valid_examples = np.random.choice(valid_window,vaild_size,replace = False)
num_sampled = 64
train_steps = 100001

def word2vec_process(input_d):
	with tf.name_scope('embed'):
		embeddings = tf.Variable(tf.random_uniform([vocabulary_size,embedding_size],-1.0,1.0))
		embed = tf.nn.embedding_lookup(embeddings,input_d)
	return embed

with tf.name_scope('input'):
	x = tf.placeholder(tf.int32,[None])
	y = tf.placeholder(tf.int32,[None,1])

with tf.device('/cpu:0'):
	embed = word2vec_process(x)

with tf.name_scope('loss'):
	nce_weight = tf.Variable(tf.random_normal([vocabulary_size,embedding_size],stddev = 1.0 / math.sqrt(embedding_size)))
	nce_bias = tf.Variable(tf.zeros([vocabulary_size]))
	loss = tf.reduce_mean(tf.nn.nce_loss(weights = nce_weight,biases = nce_bias,labels = y,inputs = embed,num_sampled = num_sampled,num_classes = vocabulary_size))

with tf.name_scope('train'):
	train_step = tf.train.GradientDescentOptimizer(1.0).minimize(loss)
	
save=tf.train.Saver()

with tf.Session() as sess:
	init = tf.global_variables_initializer()
	sess.run(init)
	average_loss = 0
	merge = tf.summary.merge_all()
	writer = tf.summary.FileWriter('log/',sess.graph)
	for i in range(train_steps):
		batch,labels = gernerate_batch(batch_size,num_skips,skip_window)
		feed_dict = {x:batch,y:labels}
		_ , loss_val = sess.run([train_step,loss],feed_dict = feed_dict)
		average_loss = average_loss + loss_val
		if(i%2000 == 0):
			if(i>0):
				average_loss = average_loss / 2000
			print('after %d steps,the loss is %g'%(i,average_loss))
	

	